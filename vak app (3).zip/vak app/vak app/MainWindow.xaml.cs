﻿using vak_app.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace vak_app
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        vakDB _vakDB = new vakDB();
        string _ownerId;
        private string ownerId;

        public MainWindow()
        {
          

            InitializeComponent();
            Showcars();

        }
        private void Link_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
            e.Handled = true;
        }
        private void Showcars()
        {
        
            DataTable dv = _vakDB.Selectdv();

            foreach (DataRow row in dv.Rows)
            {
                StackPanel panel = new StackPanel()
                {
                    Width = 200,
                    Margin = new Thickness(20)
                };
                TextBlock huiswerk = new TextBlock()
                {
                    Text = row["huiswerk"].ToString()
                };

                TextBlock toets = new TextBlock()
                {
                    Text = row["toets"].ToString(),
                    TextWrapping = TextWrapping.Wrap
                };
               


                Button btEdit = new Button()
                {
                    Content = "Change",
                    Tag = row
                };
               // btEdit.Click += btEdit_Click;
                Button btDelete = new Button()
                {
                    Content = "Delete",
                    Tag = row["idchassinnr"]

                };
                //btDelete.Click += btDelete_Click;

                Button btCreate = new Button()
                {
                    Content = "Create",
                    Tag = row

                };
              //  btCreate.Click += btCreate_Click;

                //Button link = new Button()
                //{
                //    Content = "Naar de liedjes",
                //    Tag = row["chassisnr"],
                //};



                panel.Children.Add(huiswerk);

                panel.Children.Add(toets);

         

                panel.Children.Add(btEdit);

                panel.Children.Add(btDelete);

                panel.Children.Add(btCreate);

                //  panel.Children.Add(link);

                sptoets.Children.Add(panel);
            }

        }
    }
}
