﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vak_app.Classes
{
    public class vakDB
    {
        MySqlConnection _connection = new MySqlConnection("Server=localhost;Database=vakapp;Uid=root;Pwd=;");

        public DataTable Selectdv()
        {
            DataTable result = new DataTable();
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "SELECT * FROM dv;";

                MySqlDataReader reader = command.ExecuteReader();
                result.Load(reader);
            }
            catch (Exception e)
            {
                //Problem with the databas
            }
            finally
            {
                _connection.Close();
            }
            return result;
        }
    }
}
