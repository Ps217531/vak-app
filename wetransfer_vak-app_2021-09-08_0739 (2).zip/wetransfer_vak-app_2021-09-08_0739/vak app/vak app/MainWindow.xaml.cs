﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace vak_app
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        vakDB _vakDB = new vakDB();
        public MainWindow()
        {
            InitializeComponent();

        }
        private void FillDataGrid(string _partijId)
        {
            DataTable cars = _vakDB.Selectverkiezingen(_partijId);
            //if (cars != null)
            //{
            //    dgpartijen.ItemsSource = cars.DefaultView;
            //}
        }

        private void Button_Nederlands(object sender, RoutedEventArgs e)
        {
            
        }

        private void Button_Engels(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Programmeren(object sender, RoutedEventArgs e)
        {

        }

        private void Button_DigitaleVaardigheden(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Rekenen(object sender, RoutedEventArgs e)
        {

        }

        private void Button_GUI(object sender, RoutedEventArgs e)
        {

        }

        private void Button_LogIn(object sender, RoutedEventArgs e)
        {

        }
    }
}
