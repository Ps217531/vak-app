﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //MySqlConnection _con = new MySqlConnection("Server=localhost;Database=vakapp;Uid=root;Pwd=;SSL Mode=None;");
        //int i;
        public MainWindow()
        {
            InitializeComponent();
           
        }

       

        private void login_button_Click(object sender, RoutedEventArgs e)
        {
            if (textBoxEmail.Text == null || passwordBox1.Password == null)
            {
                MessageBox.Show("Voer A.U.B een geldige gebruikersnaam of wachtwoord in!");
                textBoxEmail.Text = "";
                passwordBox1.Password = "";

            }else if (textBoxEmail.Text == "Peter" && passwordBox1.Password == "summa2021")
            {
                MessageBox.Show("Succesful ingelogd!");
                this.Hide();
                main main = new main();
                main.Show();
            }
            else
            {
                MessageBox.Show("Voer A.U.B een geldige gebruikersnaam of wachtwoord in!");
                textBoxEmail.Text = "";
                passwordBox1.Password = "";
            }
            //i = 0;
           
            //_con.Open();
            //MySqlCommand cmd = _con.CreateCommand();
            //cmd.CommandType = CommandType.Text;
            //cmd.CommandText = "select * from login where gebruikersnaam'" + textBoxEmail.Text + "' and wachtwoord'" + passwordBox1.Password + "'";
            //cmd.ExecuteNonQuery();
            //DataTable dt = new DataTable();
            //MySqlDataAdapter da = new MySqlDataAdapter(cmd); 
            //da.Fill(dt);
            //i = Convert.ToInt32(dt.Rows.Count.ToString());

            //if (i == 0)
            //{
            //    MessageBox.Show("Voer geldige gebruikersnaam of wachtwoord in!");
            //}
            //else
            //{
            //    this.Hide();
            //    main main = new main();
            //    main.Show();
            //}
            //_con.Close();
          


        }
    }
}
