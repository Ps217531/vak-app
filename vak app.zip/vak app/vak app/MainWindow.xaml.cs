﻿using vak_app.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace vak_app
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        vakDB _vakDB = new vakDB();
        public MainWindow()
        {
            InitializeComponent();

        }



        private void MouseDoubleClick(object sender, MouseEventArgs e)
        {
            dv dv = new dv();
            dv.Show();
        }

        private void Button_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            nederlands nl = new nederlands();
            nl.Show();
        }

        private void Button_MouseDoubleClick_1(object sender, MouseButtonEventArgs e)
        {
            engels en = new engels();
            en.Show();
        }

        private void Button_MouseDoubleClick_2(object sender, MouseButtonEventArgs e)
        {
            programmeren programmeren = new programmeren();
            programmeren.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            rekenen rekenen = new rekenen();
            rekenen.Show();
        }

        private void Button_MouseDoubleClick_3(object sender, MouseButtonEventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide();
        }
    }
}
