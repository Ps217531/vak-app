﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vak_app.Classes
{
    public class vakDB
    {
     
        MySqlConnection _connection = new MySqlConnection("Server=localhost;Database=vakapp;Uid=root;Pwd=;SSL Mode=None;");

        public DataTable Selectdv()
        {
            DataTable result = new DataTable();
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
               command.CommandText = "SELECT * FROM dv;";
               //command.CommandText = "SELECT * FROM dv WHERE dv_id = @id_dv;";
               //command.Parameters.AddWithValue("@id_dv", id_dv);

                MySqlDataReader reader = command.ExecuteReader();
                result.Load(reader);
            }
            catch (Exception e)
            {
                //Problem with the databas
            }
            finally
            {
                _connection.Close();
            }
            return result;
        }

        public DataTable Selectnl()
        {
            DataTable result = new DataTable();
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "SELECT * FROM nederlands;";
                //command.CommandText = "SELECT * FROM dv WHERE dv_id = @id_dv;";
                //command.Parameters.AddWithValue("@id_dv", id_dv);

                MySqlDataReader reader = command.ExecuteReader();
                result.Load(reader);
            }
            catch (Exception e)
            {
                //Problem with the databas
            }
            finally
            {
                _connection.Close();
            }
            return result;
        }

        public DataTable Selectrekenen()
        {
            DataTable result = new DataTable();
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "SELECT * FROM rekenen;";
                //command.CommandText = "SELECT * FROM dv WHERE dv_id = @id_dv;";
                //command.Parameters.AddWithValue("@id_dv", id_dv);

                MySqlDataReader reader = command.ExecuteReader();
                result.Load(reader);
            }
            catch (Exception e)
            {
                //Problem with the databas
            }
            finally
            {
                _connection.Close();
            }
            return result;
        }

        public DataTable Selectengels()
        {
            DataTable result = new DataTable();
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "SELECT * FROM engels;";
                //command.CommandText = "SELECT * FROM dv WHERE dv_id = @id_dv;";
                //command.Parameters.AddWithValue("@id_dv", id_dv);

                MySqlDataReader reader = command.ExecuteReader();
                result.Load(reader);
            }
            catch (Exception e)
            {
                //Problem with the databas
            }
            finally
            {
                _connection.Close();
            }
            return result;
        }

        public DataTable Selectprogrammeren()
        {
            DataTable result = new DataTable();
            try
            {
                _connection.Open();
                MySqlCommand command = _connection.CreateCommand();
                command.CommandText = "SELECT * FROM programmeren;";
                //command.CommandText = "SELECT * FROM dv WHERE dv_id = @id_dv;";
                //command.Parameters.AddWithValue("@id_dv", id_dv);

                MySqlDataReader reader = command.ExecuteReader();
                result.Load(reader);
            }
            catch (Exception e)
            {
                //Problem with the databas
            }
            finally
            {
                _connection.Close();
            }
            return result;
        }
    }
}
