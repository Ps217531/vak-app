﻿using vak_app.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace vak_app
{
    /// <summary>
    /// Interaction logic for nederlands.xaml
    /// </summary>
    public partial class programmeren : Window
    {

        vakDB _vakDB = new vakDB();


        public programmeren()
        {

            InitializeComponent();
            Showtoetsdv();

        }


        private void Showtoetsdv()
        {

            DataTable dv = _vakDB.Selectprogrammeren();

            foreach (DataRow row in dv.Rows)
            {
                StackPanel panel = new StackPanel()
                {
                    Width = 100,
                    Margin = new Thickness(20)
                };
                TextBlock huiswerk = new TextBlock()
                {
                    Text = row["huiswerk"].ToString()
                };

                //TextBlock toets = new TextBlock()
                //{
                //    Text = row["toets"].ToString(),
                //    TextWrapping = TextWrapping.Wrap
                //};

                panel.Children.Add(huiswerk);

                //panel.Children.Add(toets);




                //  panel.Children.Add(link);

                sptoets.Children.Add(panel);
            }

        }
    }
}
